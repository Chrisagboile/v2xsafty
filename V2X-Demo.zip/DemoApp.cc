#include "DemoApp.h"
#include "veins/modules/messages/WaveShortMessage_m.h"

using namespace veins;

Define_Module(DemoApp);

void DemoApp::initialize(int stage) {
    BaseWaveApplLayer::initialize(stage);
    if (stage == 0) {
        EV << "DemoApp initialized for " << getParentModule()->getFullPath() << endl;
    }
}

void DemoApp::onWSM(WaveShortMessage* wsm) {
    EV << "Received WSM from " << wsm->getSenderAddress() << endl;
}

void DemoApp::handleSelfMsg(cMessage* msg) {
    // Example FSM step: broadcast heartbeat
    WaveShortMessage* wsm = new WaveShortMessage();
    populateWSM(wsm);
    wsm->setWsmData("Hello from DemoApp");
    sendDown(wsm);

    scheduleAt(simTime() + 1, new cMessage("periodic"));
}
