import traci

def run_fsm():
    step = 0
    while step < 200:
        traci.simulationStep()
        for v in traci.vehicle.getIDList():
            speed = traci.vehicle.getSpeed(v)
            if speed < 1.0:
                traci.vehicle.setSpeed(v, 5.0)  # simple FSM rule: keep moving
        step += 1

if __name__ == "__main__":
    traci.start(["sumo-gui", "-c", "sumo/demo.sumocfg"])
    run_fsm()
    traci.close()
