#ifndef __VEINS_DEMOAPP_H_
#define __VEINS_DEMOAPP_H_

#include "veins/modules/application/ieee80211p/BaseWaveApplLayer.h"

class DemoApp : public veins::BaseWaveApplLayer {
  protected:
    virtual void initialize(int stage) override;
    virtual void onWSM(veins::WaveShortMessage* wsm) override;
    virtual void handleSelfMsg(cMessage* msg) override;
};

#endif
